package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Command word: back
 * Returns the adventurer to the previously visited room.
 */
public class BackCommand extends Command {

    /**
     * Moves the adventurer back to the previous room, if one exists.
     *
     * @param player the current player
     * @return false always
     */
    @Override
    public boolean execute(Player player) {
        if (!(player instanceof Adventurer)) {
            System.out.println("Error: unknown player type.");
            return false;
        }
        Adventurer adventurer = (Adventurer) player;
        Room prev = adventurer.getPreviousRoom();

        if (prev == null) {
            System.out.println("You have nowhere to go back to.");
        } else {
            Room current = adventurer.getCurrentRoom();
            adventurer.setPreviousRoom(current);
            adventurer.setCurrentRoom(prev);
            System.out.println(prev.getLongDescription());
        }
        return false;
    }
}
