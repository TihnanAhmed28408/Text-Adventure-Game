package p5adventure;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Entry point for the European Football Stadium Hunt.
 * Run this class to start the game.
 */
public class PlayGame {
    public static void main(String[] args) {
        AdventureGame game = new AdventureGame();
        game.play();
    }
}
