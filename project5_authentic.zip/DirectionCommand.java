package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Handles all 12 directional movement commands:
 * north, south, east, west, up, down, n, s, e, w, u, d.
 * One class supports all 12 command words.
 */
public class DirectionCommand extends Command {

    private String direction;

    /**
     * Creates a DirectionCommand for the given direction word.
     *
     * @param direction the direction string (e.g. "north", "n", "east")
     */
    public DirectionCommand(String direction) {
        this.direction = direction;
    }

    /**
     * Moves the adventurer in the stored direction.
     * Updates the adventurer's previous room before moving.
     *
     * @param player the current player
     * @return false always (movement alone does not end the game)
     */
    @Override
    public boolean execute(Player player) {
        // Safe cast: guard against unexpected player types
        if (!(player instanceof Adventurer)) {
            System.out.println("Error: unknown player type.");
            return false;
        }
        Adventurer adventurer = (Adventurer) player;

        // Guard: player must be in a room
        Room current = adventurer.getCurrentRoom();
        if (current == null) {
            System.out.println("You are nowhere. Something went wrong.");
            return false;
        }

        // Normalise abbreviations to full direction names
        String fullDir = normalise(direction);
        Room next = current.getExit(fullDir);

        if (next == null) {
            System.out.println("There is no exit in that direction.");
        } else {
            adventurer.setPreviousRoom(current);
            adventurer.setCurrentRoom(next);
            System.out.println(next.getLongDescription());
        }
        return false;
    }

    /** Maps abbreviations to full direction names. */
    private String normalise(String dir) {
        switch (dir.toLowerCase()) {
            case "n": return "north";
            case "s": return "south";
            case "e": return "east";
            case "w": return "west";
            case "u": return "up";
            case "d": return "down";
            default:  return dir.toLowerCase();
        }
    }
}
