package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Command word: drop
 * Allows the adventurer to drop a carried item into the current location.
 */
public class DropCommand extends Command {

    /**
     * Drops the named item from the adventurer's inventory into the current room.
     *
     * @param player the current player
     * @return false always
     */
    @Override
    public boolean execute(Player player) {
        if (!(player instanceof Adventurer)) {
            System.out.println("Error: unknown player type.");
            return false;
        }
        Adventurer adventurer = (Adventurer) player;
        String itemName = getSecondWord();

        if (itemName == null) {
            System.out.println("Drop what? (e.g. 'drop scarf')");
            return false;
        }

        Item item = adventurer.removeItem(itemName);
        if (item == null) {
            System.out.println("You aren't carrying a '" + itemName + "'.");
        } else {
            Room currentRoom = adventurer.getCurrentRoom();
            if (!(currentRoom instanceof Location)) {
                System.out.println("You can't drop items here.");
                adventurer.addItem(item); // return item to inventory
                return false;
            }
            Location current = (Location) currentRoom;
            current.addItem(item);
            System.out.println("You drop the " + item.getName() + ".");
        }
        return false;
    }
}
