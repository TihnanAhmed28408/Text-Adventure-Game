package p5adventure;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * JUnit tests for the Item class.
 */
public class ItemTest {

    private Item removableItem;
    private Item fixedItem;

    @Before
    public void setUp() {
        removableItem = new Item("scarf", "A red and white scarf.", 2);
        fixedItem     = new Item("pitch", "The stadium pitch.", 100, false);
    }

    @Test
    public void testConstructorThreeArgs() {
        assertEquals("scarf", removableItem.getName());
        assertEquals("A red and white scarf.", removableItem.getDescription());
        assertEquals(2, removableItem.getWeight());
        assertTrue("Default removable should be true", removableItem.isRemovable());
    }

    @Test
    public void testConstructorFourArgs() {
        assertEquals("pitch", fixedItem.getName());
        assertFalse("Fixed item should not be removable", fixedItem.isRemovable());
    }

    @Test
    public void testSetName() {
        removableItem.setName("badge");
        assertEquals("badge", removableItem.getName());
    }

    @Test
    public void testSetDescription() {
        removableItem.setDescription("Updated description.");
        assertEquals("Updated description.", removableItem.getDescription());
    }

    @Test
    public void testSetWeight() {
        removableItem.setWeight(5);
        assertEquals(5, removableItem.getWeight());
    }

    @Test
    public void testToString() {
        String result = removableItem.toString();
        assertTrue(result.contains("scarf"));
        assertTrue(result.contains("2"));
    }
}
