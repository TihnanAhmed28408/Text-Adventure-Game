package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Command word: look
 * Prints the full description of the adventurer's current location,
 * including exits and items present.
 */
public class LookCommand extends Command {

    /**
     * Prints the long description of the current room.
     *
     * @param player the current player
     * @return false always
     */
    @Override
    public boolean execute(Player player) {
        if (player == null) {
            return false;
        }
        Room currentRoom = player.getCurrentRoom();
        if (currentRoom == null) {
            System.out.println("You are nowhere. Something went wrong.");
            return false;
        }
        System.out.println(currentRoom.getLongDescription());
        return false;
    }
}
