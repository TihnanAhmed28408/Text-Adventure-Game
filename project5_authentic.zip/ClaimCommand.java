package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Command word: claim
 * Used at UEFA Headquarters to claim the Golden Boot trophy and win the game.
 * Win condition: adventurer must be at UEFA Headquarters AND carrying all 10 collectibles.
 *
 * Win/lose logic is implemented here in execute(Player) — see lines 47–66.
 */
public class ClaimCommand extends Command {

    /**
     * Attempts to claim the Golden Boot at UEFA Headquarters.
     * Prints a victory message and returns true if the win condition is met.
     * The win condition: player is at UEFA Headquarters with all 10 collectibles.
     *
     * @param player the current player
     * @return true if the game is won, false otherwise
     */
    @Override
    public boolean execute(Player player) {
        if (!(player instanceof Adventurer)) {
            System.out.println("Error: unknown player type.");
            return false;
        }
        Adventurer adventurer = (Adventurer) player;

        // Null-safe room check
        Room currentRoom = adventurer.getCurrentRoom();
        String roomDesc = (currentRoom != null) ? currentRoom.getShortDescription() : "";
        if (!roomDesc.contains("UEFA Headquarters")) {
            System.out.println("There's nothing to claim here. Head to UEFA Headquarters!");
            return false;
        }

        int collected = adventurer.getInventory().size();

        if (collected < 10) {
            System.out.println("The UEFA official looks at your bag and shakes his head.");
            System.out.println("\"You need collectibles from ALL 10 stadiums to claim the Golden Boot.\"");
            System.out.println("You have " + collected + "/10. Keep exploring!");
            return false;
        }

        // WIN CONDITION MET
        System.out.println("\n" +
            "╔══════════════════════════════════════════════════════════════╗\n" +
            "║           🏆  CONGRATULATIONS, STADIUM HUNTER!  🏆           ║\n" +
            "╠══════════════════════════════════════════════════════════════╣\n" +
            "║                                                              ║\n" +
            "║  You have collected memorabilia from all 10 legendary        ║\n" +
            "║  European football stadiums!                                 ║\n" +
            "║                                                              ║\n" +
            "║  The UEFA President steps forward, clapping slowly.          ║\n" +
            "║  'Remarkable. No one has ever completed the Stadium Hunt     ║\n" +
            "║   in a single journey. The Golden Boot is yours.'            ║\n" +
            "║                                                              ║\n" +
            "║  You raise the gleaming Golden Boot above your head as       ║\n" +
            "║  cameras flash across the UEFA atrium.                       ║\n" +
            "║                                                              ║\n" +
            "║                  ⚽  GAME COMPLETE  ⚽                        ║\n" +
            "╚══════════════════════════════════════════════════════════════╝");

        return true; // signals game over / win
    }
}
