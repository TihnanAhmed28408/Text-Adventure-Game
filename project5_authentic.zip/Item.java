package p5adventure;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Represents a collectible or non-collectible item in the European Football Stadium Hunt.
 * Items can be scarf, trophy, jersey, or other memorabilia found at each stadium.
 */
public class Item {
    private String name;
    private String description;
    private int weight;
    private boolean removable;

    /**
     * Creates an Item with a name, description, weight, and removability.
     *
     * @param name        the item's name
     * @param description a description of the item
     * @param weight      the item's weight
     * @param removable   true if the item can be picked up, false otherwise
     */
    public Item(String name, String description, int weight, boolean removable) {
        this.name = name;
        this.description = description;
        this.weight = weight;
        this.removable = removable;
    }

    /**
     * Creates a removable Item with the three common fields.
     *
     * @param name        the item's name
     * @param description a description of the item
     * @param weight      the item's weight
     */
    public Item(String name, String description, int weight) {
        this(name, description, weight, true);
    }

    /** @return the item's name */
    public String getName() { return name; }

    /** @param name the new name */
    public void setName(String name) { this.name = name; }

    /** @return the item's description */
    public String getDescription() { return description; }

    /** @param description the new description */
    public void setDescription(String description) { this.description = description; }

    /** @return the item's weight */
    public int getWeight() { return weight; }

    /** @param weight the new weight */
    public void setWeight(int weight) { this.weight = weight; }

    /** @return true if the item can be picked up */
    public boolean isRemovable() { return removable; }

    @Override
    public String toString() {
        return name + " (weight: " + weight + ") - " + description;
    }
}
