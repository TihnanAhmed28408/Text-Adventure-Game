package p5adventure;

import student.adventure.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for all user-defined Command classes.
 *
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 */
public class CommandTest {

    private Adventurer adventurer;
    private Location room;
    private Item scarf;

    /** initializes objects */
    @Before
    public void setUp() {
        adventurer = new Adventurer();
        room       = new Location("at Wanda Metropolitano");
        scarf      = new Item("scarf",
            "A red and white Atletico Madrid scarf.", 2);
        room.addItem(scarf);
        adventurer.setCurrentRoom(room);
    }

    /** tests TakeCommand moves item from room to inventory */
    @Test
    public void testTakeCommandMovesItemToInventory() {
        TakeCommand cmd = new TakeCommand();
        cmd.setSecondWord("scarf");
        cmd.execute(adventurer);
        assertEquals(1, adventurer.getInventory().size());
        assertTrue(room.getItems().isEmpty());
    }

    /** tests TakeCommand returns false */
    @Test
    public void testTakeCommandReturnsFalse() {
        TakeCommand cmd = new TakeCommand();
        cmd.setSecondWord("scarf");
        assertFalse(cmd.execute(adventurer));
    }

    /** tests TakeCommand with no second word */
    @Test
    public void testTakeCommandNoSecondWord() {
        TakeCommand cmd = new TakeCommand();
        assertFalse(cmd.execute(adventurer));
        assertTrue(adventurer.getInventory().isEmpty());
    }

    /** tests TakeCommand when item is not in the room */
    @Test
    public void testTakeCommandItemNotInRoom() {
        TakeCommand cmd = new TakeCommand();
        cmd.setSecondWord("badge");
        cmd.execute(adventurer);
        assertTrue(adventurer.getInventory().isEmpty());
    }

    /** tests TakeCommand does not pick up non-removable items */
    @Test
    public void testTakeCommandNonRemovableItem() {
        Item fixed = new Item("pitch", "The pitch.", 10, false);
        room.addItem(fixed);
        TakeCommand cmd = new TakeCommand();
        cmd.setSecondWord("pitch");
        cmd.execute(adventurer);
        assertTrue(adventurer.getInventory().isEmpty());
    }

    /** tests DropCommand moves item from inventory to room */
    @Test
    public void testDropCommandMovesItemToRoom() {
        adventurer.addItem(scarf);
        room.getItems().clear();
        DropCommand cmd = new DropCommand();
        cmd.setSecondWord("scarf");
        cmd.execute(adventurer);
        assertTrue(adventurer.getInventory().isEmpty());
        assertEquals(1, room.getItems().size());
    }

    /** tests DropCommand when item is not in inventory */
    @Test
    public void testDropCommandItemNotInInventory() {
        DropCommand cmd = new DropCommand();
        cmd.setSecondWord("badge");
        assertFalse(cmd.execute(adventurer));
    }

    /** tests DropCommand always returns false */
    @Test
    public void testDropCommandReturnsAlwaysFalse() {
        adventurer.addItem(scarf);
        DropCommand cmd = new DropCommand();
        cmd.setSecondWord("scarf");
        assertFalse(cmd.execute(adventurer));
    }

    /** tests InventoryCommand always returns false */
    @Test
    public void testInventoryCommandReturnsAlwaysFalse() {
        InventoryCommand cmd = new InventoryCommand();
        assertFalse(cmd.execute(adventurer));
    }

    /** tests InventoryCommand with items in inventory */
    @Test
    public void testInventoryCommandWithItems() {
        adventurer.addItem(scarf);
        InventoryCommand cmd = new InventoryCommand();
        assertFalse(cmd.execute(adventurer));
        assertEquals(1, adventurer.getInventory().size());
    }

    /** tests BackCommand when there is no previous room */
    @Test
    public void testBackCommandNoPreviousRoom() {
        BackCommand cmd = new BackCommand();
        assertFalse(cmd.execute(adventurer));
        assertEquals(room, adventurer.getCurrentRoom());
    }

    /** tests BackCommand returns player to previous room */
    @Test
    public void testBackCommandReturnsToPreviousRoom() {
        Location prevRoom = new Location("previous room");
        adventurer.setPreviousRoom(prevRoom);
        BackCommand cmd = new BackCommand();
        cmd.execute(adventurer);
        assertEquals(prevRoom, adventurer.getCurrentRoom());
    }

    /** tests BackCommand updates previous room correctly */
    @Test
    public void testBackCommandUpdatesPreviousRoom() {
        Location prevRoom = new Location("previous room");
        adventurer.setPreviousRoom(prevRoom);
        BackCommand cmd = new BackCommand();
        cmd.execute(adventurer);
        assertEquals(room, adventurer.getPreviousRoom());
    }

    /** tests LookCommand always returns false */
    @Test
    public void testLookCommandReturnsAlwaysFalse() {
        LookCommand cmd = new LookCommand();
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ExamineCommand with no second word */
    @Test
    public void testExamineCommandNoSecondWord() {
        ExamineCommand cmd = new ExamineCommand();
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ExamineCommand finds item in room */
    @Test
    public void testExamineCommandFindsItemInRoom() {
        ExamineCommand cmd = new ExamineCommand();
        cmd.setSecondWord("scarf");
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ExamineCommand finds item in inventory */
    @Test
    public void testExamineCommandFindsItemInInventory() {
        adventurer.addItem(scarf);
        room.getItems().clear();
        ExamineCommand cmd = new ExamineCommand();
        cmd.setSecondWord("scarf");
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ScoreCommand always returns false */
    @Test
    public void testScoreCommandReturnsAlwaysFalse() {
        ScoreCommand cmd = new ScoreCommand();
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ScoreCommand with 10 items collected */
    @Test
    public void testScoreCommandFullInventory() {
        for (int i = 0; i < 10; i++) {
            adventurer.addItem(new Item("item" + i, "desc", 1));
        }
        ScoreCommand cmd = new ScoreCommand();
        assertFalse(cmd.execute(adventurer));
        assertEquals(10, adventurer.getInventory().size());
    }

    /** tests DirectionCommand when there is no exit */
    @Test
    public void testDirectionCommandNoExit() {
        DirectionCommand cmd = new DirectionCommand("north");
        cmd.execute(adventurer);
        assertEquals("Player should not move when no exit",
            room, adventurer.getCurrentRoom());
    }

    /** tests DirectionCommand moves player to the next room */
    @Test
    public void testDirectionCommandMovesPlayer() {
        Location north = new Location("north room");
        room.setExit("north", north);
        DirectionCommand cmd = new DirectionCommand("north");
        cmd.execute(adventurer);
        assertEquals(north, adventurer.getCurrentRoom());
    }

    /** tests DirectionCommand updates previous room */
    @Test
    public void testDirectionCommandUpdatesPreviousRoom() {
        Location north = new Location("north room");
        room.setExit("north", north);
        DirectionCommand cmd = new DirectionCommand("north");
        cmd.execute(adventurer);
        assertEquals(room, adventurer.getPreviousRoom());
    }

    /** tests DirectionCommand handles the n abbreviation */
    @Test
    public void testDirectionCommandAbbreviationN() {
        Location north = new Location("north room");
        room.setExit("north", north);
        DirectionCommand cmd = new DirectionCommand("n");
        cmd.execute(adventurer);
        assertEquals(north, adventurer.getCurrentRoom());
    }

    /** tests DirectionCommand always returns false */
    @Test
    public void testDirectionCommandReturnsAlwaysFalse() {
        DirectionCommand cmd = new DirectionCommand("north");
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ClaimCommand returns false when not at UEFA HQ */
    @Test
    public void testClaimCommandNotAtUefaReturnsFalse() {
        ClaimCommand cmd = new ClaimCommand();
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ClaimCommand returns false at UEFA HQ without all items */
    @Test
    public void testClaimCommandAtUefaWithoutAllItemsReturnsFalse() {
        Location uefaHQ = new Location(
            "at UEFA Headquarters in Nyon, Switzerland");
        adventurer.setCurrentRoom(uefaHQ);
        for (int i = 0; i < 5; i++) {
            adventurer.addItem(new Item("item" + i, "desc", 1));
        }
        ClaimCommand cmd = new ClaimCommand();
        assertFalse(cmd.execute(adventurer));
    }

    /** tests ClaimCommand returns true at UEFA HQ with all 10 items */
    @Test
    public void testClaimCommandAtUefaWithAllItemsReturnsTrue() {
        Location uefaHQ = new Location(
            "at UEFA Headquarters in Nyon, Switzerland");
        adventurer.setCurrentRoom(uefaHQ);
        for (int i = 0; i < 10; i++) {
            adventurer.addItem(new Item("item" + i, "desc", 1));
        }
        ClaimCommand cmd = new ClaimCommand();
        assertTrue("Claim with 10 items at UEFA HQ should return true",
            cmd.execute(adventurer));
    }

    /** tests addItem returns false for null item */
    @Test
    public void testAdventurerAddItemNullReturnsFalse() {
        assertFalse(adventurer.addItem(null));
    }

    /** tests removeItem returns null for null name */
    @Test
    public void testAdventurerRemoveItemNullNameReturnsNull() {
        assertNull(adventurer.removeItem(null));
    }

    /** tests Location removeItem returns null for null name */
    @Test
    public void testLocationRemoveItemNullNameReturnsNull() {
        assertNull(room.removeItem(null));
    }
}
