package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Command word: examine
 * Displays the description of an item in the current room or in the adventurer's inventory.
 */
public class ExamineCommand extends Command {

    /**
     * Prints the description of the named item.
     * Checks the current room first, then the adventurer's inventory.
     *
     * @param player the current player
     * @return false always
     */
    @Override
    public boolean execute(Player player) {
        if (!(player instanceof Adventurer)) {
            System.out.println("Error: unknown player type.");
            return false;
        }
        Adventurer adventurer = (Adventurer) player;
        String itemName = getSecondWord();

        if (itemName == null) {
            System.out.println("Examine what? (e.g. 'examine scarf')");
            return false;
        }

        // Search room items (only if room is a Location)
        Room currentRoom = adventurer.getCurrentRoom();
        if (currentRoom instanceof Location) {
            Location current = (Location) currentRoom;
            for (Item item : current.getItems()) {
                if (item != null && itemName.equalsIgnoreCase(item.getName())) {
                    System.out.println(item.getName() + ": " + item.getDescription());
                    return false;
                }
            }
        }

        // Search inventory
        for (Item item : adventurer.getInventory()) {
            if (item != null && itemName.equalsIgnoreCase(item.getName())) {
                System.out.println(item.getName() + ": " + item.getDescription());
                return false;
            }
        }

        System.out.println("You don't see any '" + itemName + "' here or in your bag.");
        return false;
    }
}
