package p5adventure;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * JUnit tests for the Location class.
 */
public class LocationTest {

    private Location location;
    private Item removable;
    private Item fixed;

    @Before
    public void setUp() {
        location  = new Location("at Wanda Metropolitano");
        removable = new Item("scarf", "A red and white scarf.", 2);
        fixed     = new Item("pitch", "The pitch.", 100, false);
    }

    @Test
    public void testConstructorDescription() {
        assertEquals("at Wanda Metropolitano", location.getShortDescription());
    }

    @Test
    public void testInitialItemsEmpty() {
        assertTrue("Items should start empty", location.getItems().isEmpty());
    }

    @Test
    public void testAddItem() {
        location.addItem(removable);
        assertEquals(1, location.getItems().size());
        assertEquals("scarf", location.getItems().get(0).getName());
    }

    @Test
    public void testAddMultipleItems() {
        location.addItem(removable);
        location.addItem(fixed);
        assertEquals(2, location.getItems().size());
    }

    @Test
    public void testRemoveItemSuccess() {
        location.addItem(removable);
        Item removed = location.removeItem("scarf");
        assertNotNull(removed);
        assertEquals("scarf", removed.getName());
        assertTrue("Room should be empty after removal", location.getItems().isEmpty());
    }

    @Test
    public void testRemoveItemNotFound() {
        Item removed = location.removeItem("badge");
        assertNull("Should return null when item not found", removed);
    }

    @Test
    public void testRemoveItemNotRemovable() {
        location.addItem(fixed);
        Item removed = location.removeItem("pitch");
        assertNull("Should return null for non-removable item", removed);
        assertEquals("Fixed item should still be in room", 1, location.getItems().size());
    }

    @Test
    public void testGetLongDescriptionContainsItems() {
        location.addItem(removable);
        String desc = location.getLongDescription();
        assertTrue("Long description should mention the item", desc.contains("scarf"));
    }

    @Test
    public void testGetLongDescriptionNoItems() {
        String desc = location.getLongDescription();
        assertTrue(desc.contains("none"));
    }
}
