package p5adventure;

import student.adventure.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Represents a location (stadium or venue) in the European Football Stadium Hunt.
 * Each Location can hold any number of Item objects.
 */
public class Location extends Room {

    private List<Item> items;

    /**
     * Creates a Location with the given description and an empty item list.
     *
     * @param description a short description of the location
     */
    public Location(String description) {
        super(description);
        this.items = new ArrayList<>();
    }

    /**
     * Returns the list of items currently in this location.
     *
     * @return list of items
     */
    public List<Item> getItems() {
        return items;
    }

    /**
     * Adds an item to this location. A location can hold any number of items.
     *
     * @param item the item to add
     */
    public void addItem(Item item) {
        items.add(item);
    }

    /**
     * Removes and returns the item with the given name if it is removable.
     * Returns null if the item is not found or is not removable.
     *
     * @param name the name of the item to remove
     * @return the removed Item, or null
     */
    public Item removeItem(String name) {
        if (name == null) {
            return null;
        }
        for (Item item : items) {
            if (item != null && name.equalsIgnoreCase(item.getName())) {
                if (item.isRemovable()) {
                    items.remove(item);
                    return item;
                } else {
                    return null; // found but not removable
                }
            }
        }
        return null; // not found
    }

    /**
     * Returns the long description of this location, including all exits and items present.
     *
     * @return the full description string
     */
    @Override
    public String getLongDescription() {
        StringBuilder sb = new StringBuilder(super.getLongDescription());
        if (items.isEmpty()) {
            sb.append("\nItems here: none");
        } else {
            sb.append("\nItems here:");
            for (Item item : items) {
                sb.append("\n  - ").append(item.toString());
            }
        }
        return sb.toString();
    }
}
