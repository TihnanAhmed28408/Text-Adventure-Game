package p5adventure;

import student.adventure.*;

/**
 * @author Tihnan Ahmed (tihnan2024)
 * @version 1.0
 * Command word: score
 * Shows the adventurer's current progress — how many stadium collectibles
 * have been gathered out of the 10 required to win.
 */
public class ScoreCommand extends Command {

    /**
     * Prints the adventurer's current collection progress.
     *
     * @param player the current player
     * @return false always
     */
    @Override
    public boolean execute(Player player) {
        if (!(player instanceof Adventurer)) {
            System.out.println("Error: unknown player type.");
            return false;
        }
        Adventurer adventurer = (Adventurer) player;
        int collected = adventurer.getInventory().size();
        System.out.println("⚽ Stadium Hunt Progress: " + collected + "/10 collectibles gathered.");
        if (collected == 0) {
            System.out.println("You haven't picked up anything yet. Explore the stadiums!");
        } else if (collected < 10) {
            System.out.println("Keep going! Head to UEFA Headquarters once you have all 10.");
        } else {
            System.out.println("You have all 10! Now head to UEFA Headquarters to claim your prize!");
        }
        return false;
    }
}
